#!/bin/sh

echo "Starting CGM frontend"

nginx -g 'daemon off;'