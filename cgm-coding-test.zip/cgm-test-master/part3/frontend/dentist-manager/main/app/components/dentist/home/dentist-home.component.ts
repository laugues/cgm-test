import {Component, OnInit} from '@angular/core';

@Component({
    moduleId: module.id,
    templateUrl: 'dentist-home.component.html'
})

export class DentistHomeComponent implements OnInit {

    constructor() {
    }

    ngOnInit() {
        // reset login status

    }
}
