package com.cg.helix.persistence.exception;

/**
 * Created by SOLO on 20/09/2017.
 */
public class NoResultsException extends Exception
{
}
